(function () {
  "use strict";

  var STORE = "gofriends_designs";
  var RSTORE = "gofriends_reviews";
  var SESSION = "gofriends_admin";
  var PHONE = "9751590453";
  var ADMIN_PASS = "12345";

  var DEFAULT_CARDS = [
    { id: "d1", name: "Round Neck Blouse", img: "images/model-1.jpg", category: "blouse", isNew: true },
    { id: "d2", name: "Designer Blouse", img: "images/model-2.jpg", category: "blouse", isNew: true },
    { id: "d3", name: "Designer Blouse", img: "images/model-3.jpg", category: "blouse", isNew: true }
  ];

  var DEFAULT_REVIEWS = [
    { id: "r1", name: "Priya", stars: 5, text: "Very neat stitching, my blouse fits perfectly. Good price and ready on time!", img: "" },
    { id: "r2", name: "Kavitha", stars: 5, text: "Great tailoring shop in Vengalapuram. My daughter's school uniform was stitched very nicely.", img: "" },
    { id: "r3", name: "Meena", stars: 4, text: "Beautiful maggam work blouse. I am very happy with the service.", img: "" }
  ];

  var loginModal, adminModal, editModal;
  var editingId = null;      /* null = adding new */
  var activeTab = "designs"; /* "designs" | "reviews" */
  var activeFilter = "all";

  function load(key, fallback) {
    try {
      var d = JSON.parse(localStorage.getItem(key));
      if (d && d.length) return d;
    } catch (e) {}
    return fallback.slice();
  }
  function save(key, list) {
    try { localStorage.setItem(key, JSON.stringify(list)); }
    catch (e) { alert("Storage is full. Try a smaller photo, or delete something first."); }
  }

  var cards = load(STORE, DEFAULT_CARDS);
  var reviews = load(RSTORE, DEFAULT_REVIEWS);

  /* ================= Public gallery rendering ================= */
  function renderGallery() {
    var grid = document.getElementById("fittingsGrid");
    if (!grid) return;
    grid.innerHTML = "";
    cards.forEach(function (c) {
      if (activeFilter !== "all" && c.category !== activeFilter) return;

      var art = document.createElement("article");
      art.className = "fitting-card";
      art.setAttribute("data-category", c.category || "blouse");

      var a = document.createElement("a");
      a.href = "tel:" + PHONE;
      a.className = "fitting-photo";

      var img = document.createElement("img");
      img.src = c.img;
      img.alt = c.name;
      img.loading = "lazy";
      a.appendChild(img);

      if (c.isNew) {
        var badge = document.createElement("span");
        badge.className = "fitting-new";
        badge.textContent = "New";
        a.appendChild(badge);
      }

      var body = document.createElement("div");
      body.className = "fitting-body";
      var h = document.createElement("h3");
      h.textContent = c.name;
      body.appendChild(h);

      art.appendChild(a);
      art.appendChild(body);
      grid.appendChild(art);
    });
  }

  function categoryLabel(v) {
    return { blouse: "Blouse", girls: "Girls Dress", uniform: "School Uniform", other: "Other" }[v] || "Blouse";
  }

  /* ================= Reviews rendering ================= */
  function starsHTML(n) {
    var s = "";
    for (var i = 1; i <= 5; i++) s += i <= n ? "★" : "☆";
    return s;
  }

  function renderReviews() {
    var grid = document.getElementById("reviewsGrid");
    if (!grid) return;
    grid.innerHTML = "";
    if (!reviews.length) {
      grid.innerHTML = "<p class='review-empty'>No reviews yet — add one from the Admin panel.</p>";
      return;
    }
    reviews.forEach(function (r) {
      var card = document.createElement("div");
      card.className = "review-card";

      var top = document.createElement("div");
      top.className = "review-top";

      var ava = document.createElement("div");
      ava.className = "review-ava";
      if (r.img) {
        var img = document.createElement("img");
        img.src = r.img;
        img.alt = r.name;
        ava.appendChild(img);
      } else {
        ava.textContent = (r.name || "G").charAt(0).toUpperCase();
      }

      var head = document.createElement("div");
      head.className = "review-head";
      var name = document.createElement("strong");
      name.textContent = r.name || "Customer";
      var stars = document.createElement("span");
      stars.className = "review-stars";
      stars.textContent = starsHTML(r.stars);
      stars.setAttribute("aria-label", r.stars + " out of 5 stars");
      head.appendChild(name);
      head.appendChild(stars);

      top.appendChild(ava);
      top.appendChild(head);

      var text = document.createElement("p");
      text.className = "review-text";
      text.textContent = r.text;

      card.appendChild(top);
      card.appendChild(text);
      grid.appendChild(card);
    });
  }

  /* ================= Filters ================= */
  function initFilter() {
    var bar = document.getElementById("galleryFilter");
    if (!bar) return;
    bar.addEventListener("click", function (e) {
      var btn = e.target.closest(".filter-btn");
      if (!btn) return;
      bar.querySelectorAll(".filter-btn").forEach(function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      activeFilter = btn.getAttribute("data-filter");
      renderGallery();
    });
  }

  /* ================= Admin list rendering ================= */
  function renderAdminList() {
    var list = document.getElementById("adminList");
    if (!list) return;
    list.innerHTML = "";

    if (activeTab === "designs") {
      cards.forEach(function (c) {
        var row = document.createElement("div");
        row.className = "admin-row";

        var img = document.createElement("img");
        img.src = c.img;
        img.alt = c.name;

        var name = document.createElement("span");
        name.className = "admin-row-name";
        name.textContent = c.name + " · " + categoryLabel(c.category);

        var edit = document.createElement("button");
        edit.type = "button";
        edit.className = "btn btn-gold btn-xs";
        edit.textContent = "Edit";
        edit.addEventListener("click", function () { openEdit(c.id); });

        var del = document.createElement("button");
        del.type = "button";
        del.className = "btn btn-danger btn-xs";
        del.textContent = "Delete";
        del.addEventListener("click", function () { removeCard(c.id); });

        row.appendChild(img); row.appendChild(name); row.appendChild(edit); row.appendChild(del);
        list.appendChild(row);
      });
    } else {
      reviews.forEach(function (r) {
        var row = document.createElement("div");
        row.className = "admin-row";

        var img = document.createElement("img");
        if (r.img) { img.src = r.img; } else { img.style.background = "linear-gradient(120deg,#E8AEB7,#B0607A)"; }
        img.alt = r.name;

        var name = document.createElement("span");
        name.className = "admin-row-name";
        name.textContent = r.name + " · " + r.stars + "★";

        var edit = document.createElement("button");
        edit.type = "button";
        edit.className = "btn btn-gold btn-xs";
        edit.textContent = "Edit";
        edit.addEventListener("click", function () { openEdit(r.id); });

        var del = document.createElement("button");
        del.type = "button";
        del.className = "btn btn-danger btn-xs";
        del.textContent = "Delete";
        del.addEventListener("click", function () { removeReview(r.id); });

        row.appendChild(img); row.appendChild(name); row.appendChild(edit); row.appendChild(del);
        list.appendChild(row);
      });
      if (!reviews.length) {
        list.innerHTML = "<p class='review-empty'>No reviews yet.</p>";
      }
    }
  }

  function setView(v) {
    activeTab = v;
    document.querySelectorAll(".admin-tabs .tab").forEach(function (t) {
      t.classList.toggle("active", t.getAttribute("data-tab") === v);
    });
    document.getElementById("addBtn").textContent = v === "designs" ? "+ Add Design" : "+ Add Review";
    document.getElementById("adminHint").textContent =
      v === "designs"
        ? "Add, rename or delete design photos. Changes save automatically."
        : "Add or manage customer reviews and photos. Changes save automatically.";
    renderAdminList();
  }

  function removeCard(id) {
    if (!confirm("Delete this design?")) return;
    cards = cards.filter(function (c) { return c.id !== id; });
    save(STORE, cards);
    renderAdminList(); renderGallery();
  }
  function removeReview(id) {
    if (!confirm("Delete this review?")) return;
    reviews = reviews.filter(function (r) { return r.id !== id; });
    save(RSTORE, reviews);
    renderAdminList(); renderReviews();
  }

  /* ================= Image resize ================= */
  function resizeImage(file, cb) {
    var reader = new FileReader();
    reader.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        var max = 700, w = img.width, h = img.height;
        if (w > max) { h = h * max / w; w = max; }
        if (h > 900) { w = w * 900 / h; h = 900; }
        var cv = document.createElement("canvas");
        cv.width = Math.round(w);
        cv.height = Math.round(h);
        cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
        cb(cv.toDataURL("image/jpeg", 0.82));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  /* ================= Edit modal ================= */
  function isReviewTab() { return activeTab === "reviews"; }
  function findCurrent() {
    return (activeTab === "designs" ? cards : reviews).filter(function (x) { return x.id === editingId; })[0];
  }

  function openEdit(id) {
    editingId = id || null;
    var isNew = editingId === null;
    var review = isReviewTab();
    var cur = isNew ? null : findCurrent();

    document.getElementById("editTitle").textContent =
      review ? (isNew ? "Add Review" : "Edit Review") : (isNew ? "Add Design" : "Edit Design");

    document.getElementById("editNameLabel").textContent = review ? "Customer name" : "Design name";
    document.getElementById("editName").value = cur ? (cur.name || "") : "";
    document.getElementById("editName").placeholder = review ? "e.g. Priya" : "e.g. Round Neck Blouse";

    /* category (designs only) */
    var catEl = document.getElementById("editCategory");
    var catLab = document.getElementById("editCatLabel");
    catEl.hidden = review;
    catLab.hidden = review;
    if (!review) catEl.value = cur ? (cur.category || "blouse") : "blouse";

    /* text + stars (reviews only) */
    var txtEl = document.getElementById("editText");
    var txtLabel = document.getElementById("editTextLabel");
    var stEl = document.getElementById("editStars");
    var stLabel = document.getElementById("editStarsLabel");
    txtEl.hidden = !review;
    txtLabel.hidden = !review;
    stEl.hidden = !review;
    stLabel.hidden = !review;
    if (review) {
      txtEl.value = cur ? (cur.text || "") : "";
      stEl.value = cur ? String(cur.stars || 5) : "5";
    }

    document.getElementById("editFile").value = "";
    var preview = document.getElementById("editPreview");
    preview.hidden = true;
    preview.removeAttribute("src");
    if (!review && cur && cur.img) { preview.src = cur.img; preview.hidden = false; }
    if (review && cur && cur.img) { preview.src = cur.img; preview.hidden = false; }

    show(editModal);
  }

  function saveFromModal() {
    var name = document.getElementById("editName").value.trim();
    var fileInput = document.getElementById("editFile");
    var review = isReviewTab();

    var process = function (img) {
      var finalImg = img || (editingId && (findCurrent() || {}).img) || "";
      if (review) {
        var text = document.getElementById("editText").value.trim();
        var stars = parseInt(document.getElementById("editStars").value, 10) || 5;
        if (!name) { alert("Please enter the customer name."); return; }
        if (!text) { alert("Please write the review text."); return; }
        if (editingId === null) {
          reviews.push({ id: "r" + Date.now(), name: name, text: text, stars: stars, img: finalImg });
        } else {
          reviews.forEach(function (r) {
            if (r.id === editingId) { r.name = name; r.text = text; r.stars = stars; if (finalImg) r.img = finalImg; }
          });
        }
        save(RSTORE, reviews);
        renderAdminList(); renderReviews();
      } else {
        var cat = document.getElementById("editCategory").value;
        if (!finalImg && editingId === null) { alert("Please choose a photo."); return; }
        if (editingId === null) {
          cards.push({ id: "d" + Date.now(), name: name || "New Design", img: finalImg, category: cat, isNew: true });
        } else {
          cards.forEach(function (c) {
            if (c.id === editingId) { c.name = name || c.name; c.category = cat; if (finalImg) c.img = finalImg; }
          });
        }
        save(STORE, cards);
        renderAdminList(); renderGallery();
      }
      hide(editModal);
    };

    if (fileInput.files && fileInput.files[0]) {
      resizeImage(fileInput.files[0], process);
    } else {
      process(null);
    }
  }

  /* ================= Modal helpers ================= */
  function show(el) { el.hidden = false; }
  function hide(el) { el.hidden = true; }

  function tryLogin() {
    var pass = document.getElementById("adminPass").value;
    var err = document.getElementById("loginError");
    if (pass === ADMIN_PASS) {
      err.textContent = "";
      sessionStorage.setItem(SESSION, "1");
      hide(loginModal);
      show(adminModal);
      renderAdminList();
      document.getElementById("adminPass").value = "";
    } else {
      err.textContent = "Wrong password. Try again.";
    }
  }

  function logout() {
    sessionStorage.removeItem(SESSION);
    hide(adminModal);
  }

  /* ================= Init ================= */
  function init() {
    loginModal = document.getElementById("loginModal");
    adminModal = document.getElementById("adminModal");
    editModal = document.getElementById("editModal");

    renderGallery();
    renderReviews();
    initFilter();

    document.getElementById("adminBtn").addEventListener("click", function () {
      if (sessionStorage.getItem(SESSION)) {
        show(adminModal);
        renderAdminList();
      } else {
        show(loginModal);
        document.getElementById("adminPass").focus();
      }
    });
    document.getElementById("loginBtn").addEventListener("click", tryLogin);
    document.getElementById("loginClose").addEventListener("click", function () {
      hide(loginModal);
      document.getElementById("loginError").textContent = "";
    });
    document.getElementById("adminPass").addEventListener("keydown", function (e) {
      if (e.key === "Enter") tryLogin();
    });

    document.getElementById("adminClose").addEventListener("click", function () { hide(adminModal); });
    document.getElementById("logoutBtn").addEventListener("click", logout);

    document.querySelectorAll(".admin-tabs .tab").forEach(function (t) {
      t.addEventListener("click", function () { setView(t.getAttribute("data-tab")); });
    });

    document.getElementById("addBtn").addEventListener("click", function () { openEdit(null); });
    document.getElementById("editCancel").addEventListener("click", function () { hide(editModal); });
    document.getElementById("editSave").addEventListener("click", saveFromModal);
    document.getElementById("editFile").addEventListener("change", function () {
      var f = this.files && this.files[0];
      var preview = document.getElementById("editPreview");
      if (f) {
        resizeImage(f, function (data) { preview.src = data; preview.hidden = false; });
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
(function () {
  "use strict";

  var form = document.getElementById("bookingForm");
  if (!form) return;

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var name = document.getElementById("bkName").value.trim();
    var phone = document.getElementById("bkPhone").value.trim();
    var type = document.getElementById("bkType").value;
    var design = document.getElementById("bkDesign").value.trim();
    var meas = document.getElementById("bkMeas").value.trim();
    var date = document.getElementById("bkDate").value;
    var notes = document.getElementById("bkNotes").value.trim();

    var msg =
      "NEW ORDER - GO FRIENDS TAILORING\n" +
      "----------------------------\n" +
      "Name: " + name + "\n" +
      "Mobile: " + phone + "\n" +
      "Stitching: " + type + "\n" +
      (design ? "Design: " + design + "\n" : "") +
      (meas ? "Measurements: " + meas + "\n" : "") +
      (date ? "Need by: " + date + "\n" : "") +
      (notes ? "Notes: " + notes + "\n" : "") +
      "----------------------------\n" +
      "Sent from the GO FRIENDS website";

    var url = "https://wa.me/919751590453?text=" + encodeURIComponent(msg);
    window.open(url, "_blank", "noopener");
  });
})();
(function () {
  "use strict";

  var header = document.getElementById("header");
  var navToggle = document.getElementById("navToggle");
  var nav = document.getElementById("nav");

  function onScroll() {
    if (window.scrollY > 40) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  navToggle.addEventListener("click", function () {
    nav.classList.toggle("open");
    navToggle.classList.toggle("open");
    navToggle.setAttribute("aria-label", nav.classList.contains("open") ? "Close menu" : "Open menu");
  });

  nav.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
      nav.classList.remove("open");
      navToggle.classList.remove("open");
    });
  });

  /* Scroll reveal UX */
  var revealTargets = document.querySelectorAll(
    ".section > .container > *:not(.reveal), .hero-bg, .footer-inner"
  );
  revealTargets.forEach(function (el, i) {
    el.classList.add("reveal");
    el.style.transitionDelay = (i % 4) * 80 + "ms";
  });

  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach(function (el) { io.observe(el); });
  } else {
    revealTargets.forEach(function (el) { el.classList.add("in"); });
  }

  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();